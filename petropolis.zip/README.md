TinDog Starting Files
